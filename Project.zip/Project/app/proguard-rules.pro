# RoomWangi - keep service
-keep class com.paneer.roomwangi.service.** { *; }
