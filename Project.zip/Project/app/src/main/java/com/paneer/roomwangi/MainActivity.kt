package com.paneer.roomwangi

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.paneer.roomwangi.databinding.ActivityMainBinding
import com.paneer.roomwangi.service.DesyncEngineService
import com.paneer.roomwangi.service.DesyncMode

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var engine: DesyncEngineService? = null
    private var bound = false

    private val regions = listOf(
        "Vietnam (VN) — high soft-pool",
        "Cambodia (KH)",
        "Laos (LA)",
        "Myanmar (MM)",
        "Philippines (PH)",
        "Thailand (TH)",
        "Indonesia Soft (ID-edge)",
        "Random Soft Pool"
    )

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as DesyncEngineService.LocalBinder
            engine = binder.getService()
            bound = true
            refreshUi()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            engine = null
            bound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRegionSpinner()
        setupSeek()
        setupButtons()
        requestBatteryIgnore()
    }

    override fun onStart() {
        super.onStart()
        Intent(this, DesyncEngineService::class.java).also {
            bindService(it, connection, Context.BIND_AUTO_CREATE)
        }
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
        }
    }

    private fun setupRegionSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, regions)
        binding.spinnerRegion.adapter = adapter
    }

    private fun setupSeek() {
        binding.seekJitter.setOnSeekBarChangeListener(object :
            android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: android.widget.SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                binding.tvJitterValue.text = "$progress ms"
            }

            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {}
        })
    }

    private fun setupButtons() {
        binding.btnStart.setOnClickListener {
            val mode = when {
                binding.rbHard.isChecked -> DesyncMode.HARD
                binding.rbAntiReconnect.isChecked -> DesyncMode.ANTI_RECONNECT
                else -> DesyncMode.SOFT
            }
            val jitter = binding.seekJitter.progress.coerceIn(40, 400)
            val region = regions[binding.spinnerRegion.selectedItemPosition]

            val intent = Intent(this, DesyncEngineService::class.java).apply {
                action = DesyncEngineService.ACTION_START
                putExtra(DesyncEngineService.EXTRA_MODE, mode.name)
                putExtra(DesyncEngineService.EXTRA_JITTER, jitter)
                putExtra(DesyncEngineService.EXTRA_REGION, region)
            }
            ContextCompat.startForegroundService(this, intent)
            binding.btnStart.isEnabled = false
            binding.btnStop.isEnabled = true
            binding.tvStatus.text = getString(R.string.status_armed)
            binding.tvDetail.text =
                "Region: $region\nMode: $mode\nJitter: ${jitter}ms\nWaiting MLBB traffic…"
            Toast.makeText(this, "Engine armed. Open MLBB and queue.", Toast.LENGTH_SHORT).show()
        }

        binding.btnStop.setOnClickListener {
            val intent = Intent(this, DesyncEngineService::class.java).apply {
                action = DesyncEngineService.ACTION_STOP
            }
            startService(intent)
            binding.btnStart.isEnabled = true
            binding.btnStop.isEnabled = false
            binding.tvStatus.text = getString(R.string.status_idle)
            binding.tvDetail.text = "Engine stopped."
        }

        binding.btnOpenVpn.setOnClickListener {
            openAppOrMarket(
                listOf(
                    "net.openvpn.openvpn",
                    "de.blinkt.openvpn",
                    "com.github.shadowsocks"
                   " com.urbanvpn.android"
                )
            )
        }

        binding.btnOpenMlbb.setOnClickListener {
            openAppOrMarket(listOf("com.mobile.legends", "com.mobilelegends.hwag"))
        }
    }

    private fun openAppOrMarket(packages: List<String>) {
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                startActivity(launch)
                return
            }
        }
        try {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=${packages.first()}")
                )
            )
        } catch (_: Exception) {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=${packages.first()}")
                )
            )
        }
    }

    private fun requestBatteryIgnore() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }

    private fun refreshUi() {
        engine?.let {
            if (it.isRunning) {
                binding.btnStart.isEnabled = false
                binding.btnStop.isEnabled = true
                binding.tvStatus.text = getString(R.string.status_active)
            }
        }
    }
}
