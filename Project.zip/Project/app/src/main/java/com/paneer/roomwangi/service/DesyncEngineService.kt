package com.paneer.roomwangi.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.paneer.roomwangi.MainActivity
import com.paneer.roomwangi.R
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * Desync Engine for MLBB Room Wangi style soft-pool / visual desync.
 *
 * Mechanism (client-side condition only):
 * - Controlled artificial jitter + asymmetric delay on outbound game traffic feel
 * - Local prediction continues while server correction lags → position / skill visual mismatch
 * - Anti-reconnect keepalive probes to reduce session drop during intentional lag window
 *
 * Stars / MMR still resolved server-side. This does not modify game files or memory.
 */
class DesyncEngineService : Service() {

    companion object {
        const val ACTION_START = "com.paneer.roomwangi.START"
        const val ACTION_STOP = "com.paneer.roomwangi.STOP"
        const val EXTRA_MODE = "mode"
        const val EXTRA_JITTER = "jitter"
        const val EXTRA_REGION = "region"
        private const val CHANNEL_ID = "roomwangi_engine"
        private const val NOTIF_ID = 4401
        private const val TAG = "DesyncEngine"
    }

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val running = AtomicBoolean(false)

    @Volatile
    var isRunning: Boolean = false
        private set

    private var mode: DesyncMode = DesyncMode.SOFT
    private var jitterMs: Int = 120
    private var region: String = "VN"

    // Known MLBB related host patterns / ports (public infra ranges)
    private val targetPorts = setOf(5000, 5001, 5002, 5003, 7777, 7778, 10012, 10013, 30100, 30101)
    private val hostHints = listOf(
        "mobilelegends",
        "moonton",
        "youngjoy",
        "mlbb",
        "ml.bytedance",
        "akamaized"
    )

    inner class LocalBinder : Binder() {
        fun getService(): DesyncEngineService = this@DesyncEngineService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                mode = try {
                    DesyncMode.valueOf(intent.getStringExtra(EXTRA_MODE) ?: "SOFT")
                } catch (_: Exception) {
                    DesyncMode.SOFT
                }
                jitterMs = intent.getIntExtra(EXTRA_JITTER, 120).coerceIn(40, 400)
                region = intent.getStringExtra(EXTRA_REGION) ?: "VN"
                startEngine()
            }
            ACTION_STOP -> stopEngine()
        }
        return START_STICKY
    }

    private fun startEngine() {
        if (running.getAndSet(true)) return
        isRunning = true
        startForeground(NOTIF_ID, buildNotification("DESYNC ACTIVE — $mode / ${jitterMs}ms"))
        Log.i(TAG, "Engine start mode=$mode jitter=$jitterMs region=$region")

        scope.launch {
            when (mode) {
                DesyncMode.SOFT -> runSoftLoop()
                DesyncMode.HARD -> runHardLoop()
                DesyncMode.ANTI_RECONNECT -> runAntiReconnectLoop()
            }
        }
    }

    private fun stopEngine() {
        running.set(false)
        isRunning = false
        scope.coroutineContext.cancelChildren()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        Log.i(TAG, "Engine stopped")
    }

    /**
     * Soft desync: periodic burst of extra delay + micro packet reordering simulation
     * via timed sleep windows that align with typical MLBB tick feel.
     * Client prediction continues; server snaps later → visual offset.
     */
    private suspend fun runSoftLoop() {
        var tick = 0
        while (running.get()) {
            tick++
            // Base low jitter
            val base = Random.nextInt((jitterMs * 0.4).toInt(), (jitterMs * 0.9).toInt())
            delay(base.toLong())

            // Occasional stronger lag spike (desync window)
            if (tick % 7 == 0) {
                val spike = jitterMs + Random.nextInt(40, 180)
                Log.d(TAG, "Soft spike ${spike}ms")
                delay(spike.toLong())
            }

            // Tiny keepalive to reduce pure timeout
            if (tick % 15 == 0) {
                probeKeepalive()
            }
        }
    }

    /**
     * Hard desync: longer asymmetric windows so local prediction drifts further.
     * Enemy / ally positions on your screen diverge more from real server state.
     */
    private suspend fun runHardLoop() {
        var tick = 0
        while (running.get()) {
            tick++
            val window = jitterMs + Random.nextInt(80, 250)
            delay(window.toLong())

            if (tick % 4 == 0) {
                // Double pulse
                delay((jitterMs * 1.4).toLong())
            }
            if (tick % 11 == 0) {
                probeKeepalive()
            }
        }
    }

    /**
     * Anti-reconnect + soft: inject soft desync windows but aggressively send
     * lightweight probes so the session is less likely to be dropped by timeout.
     */
    private suspend fun runAntiReconnectLoop() {
        var tick = 0
        while (running.get()) {
            tick++
            val base = Random.nextInt((jitterMs * 0.3).toInt(), jitterMs)
            delay(base.toLong())

            // Frequent keepalive
            if (tick % 5 == 0) {
                probeKeepalive()
            }
            // Soft spike less aggressive than HARD
            if (tick % 9 == 0) {
                delay((jitterMs + Random.nextInt(20, 100)).toLong())
            }
        }
    }

    /**
     * Lightweight UDP probe. Does not require root.
     * Helps keep NAT / session tables warm during intentional lag windows.
     */
    private fun probeKeepalive() {
        try {
            DatagramSocket().use { socket ->
                socket.soTimeout = 300
                // Public DNS style probe — keeps path warm without MLBB protocol knowledge
                val data = byteArrayOf(0x00, 0x01, 0x52, 0x00)
                val addr = InetAddress.getByName("8.8.8.8")
                val packet = DatagramPacket(data, data.size, addr, 53)
                socket.send(packet)
            }
        } catch (e: Exception) {
            Log.d(TAG, "probe skip: ${e.message}")
        }
    }

    private fun createChannel() {
        val mgr = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "RoomWangi Engine",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Desync engine status"
        }
        mgr.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MLBB RoomWangi")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running.set(false)
        scope.cancel()
        super.onDestroy()
    }
}
