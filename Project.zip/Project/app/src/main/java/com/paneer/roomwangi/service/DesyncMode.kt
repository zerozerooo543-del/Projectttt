package com.paneer.roomwangi.service

enum class DesyncMode {
    SOFT,
    HARD,
    ANTI_RECONNECT
}
