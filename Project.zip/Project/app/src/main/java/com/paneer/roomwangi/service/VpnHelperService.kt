package com.paneer.roomwangi.service

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log

/**
 * Minimal VpnService shell.
 * Real OpenVPN profile should still be handled by OpenVPN for Android / similar.
 * This class exists so the app can request VPN permission and optionally
 * hold a lightweight tunnel if user configures it later.
 */
class VpnHelperService : VpnService() {

    companion object {
        private const val TAG = "VpnHelper"
    }

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Placeholder — production users connect real OpenVPN profiles externally
        Log.i(TAG, "VpnHelper start (use external OpenVPN for region profiles)")
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try {
            tun?.close()
        } catch (_: Exception) {
        }
        tun = null
        super.onDestroy()
    }
}
